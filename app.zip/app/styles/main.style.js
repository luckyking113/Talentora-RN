export default {
    backgroundColor: 'red'
}
