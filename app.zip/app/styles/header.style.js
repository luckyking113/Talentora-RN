import { StyleSheet } from 'react-native'

export const headerStyle = {
    backgroundColor: '#f6f6f6',
    borderBottomColor: '#bbb',
    borderBottomWidth: StyleSheet.hairlineWidth,
}

export const titleStyle = {
    fontSize: 16,
    color: '#333',
    // fontFamily: ''
}
